# 链上功能的取舍

## 判断标准

一个功能值得上链，当且仅当它至少占一条：

1. **可转让** —— 玩家要能卖、能送、能借
2. **无需信任的托管** —— 涉及第三方替别人保管钱
3. **可验证 / 抗篡改** —— 需要向玩家证明"我们没作弊"
4. **可组合** —— 别的应用要能读到

四条都不占的，上链纯属负担。这把尺子直接决定了下面的取舍。

## 已实现

| 功能 | 占哪条 | 合约 |
|------|--------|------|
| 皮肤所有权与自由交易 | ①④ | `WeaponSkin` / `SkinMarket` |
| 发行上限的不可违背承诺 | ③ | `GameAssetRegistry` |
| 赛事奖池托管 | ② | `TournamentEscrow` |
| 对局结果存证 | ③ | `MatchAttestation` |

## 已否决

| 想法 | 为什么不做 |
|------|-----------|
| 等级 / 经验 / 匹配分上链 | 四条一条都不占，纯增加成本和故障点 |
| 游戏内软通货（ERC-20） | 刷币即印钞，把游戏平衡问题升级成资金安全问题；叠加多地合规风险 |
| 每一枪 / 弹道上链 | 与 16ms 的实时性差 2–5 个数量级，物理上不可能 |
| 押注 / 竞猜 | 多个司法辖区直接认定为赌博 |
| **反作弊封禁记录上链** | 看着透明，实际危险：误判无法撤销，且有隐私问题。**封禁必须可申诉，与链上不可变性直接冲突** |
| 宝箱 / 开箱 | 链上随机数安全 + 多地区博彩合规，不是 hackathon 该碰的 |

倒数第二条值得单独记住：不可变性对**资产**是优点，对**惩罚记录**是缺点。

## TournamentEscrow —— 赛事奖池托管

### 解决什么

小型电竞赛事的奖金纠纷是真实且普遍的痛点：组织者收了报名费跑路、分奖不透明、
说好的赞助金不到账。

报名费一进合约，**组织者就拿不走本金**。他只能拿到创建赛事时就公开声明、且有
硬上限（10%）的抽成。分账比例在开赛前写死，事后改不了。

这比皮肤 NFT 更能体现无需信任：皮肤是"我们发给你一个 NFT"，托管是
"**我们自己也拿不走这笔钱**"。

### 不解决什么（必须说清楚）

**结果提交方说谎，合约无能为力。** `resultSubmitter` 报什么名次，就按什么分钱。

所以设计目标不是消除信任，而是**让信任假设显式且可预先审查**：

- `resultSubmitter` 在创建赛事时确定，报名前就能看到自己在信任谁；
- 报名后不可更换提交方（`test_noWayToChangeResultSubmitter` 守着）；
- 结果与 `resultHash` 一起上链，可与 `MatchAttestation` 的存证交叉核验；
- **提交方失踪也不会锁死资金** —— 过了 `resultDeadline`，任何人都能触发取消并
  全额退款。这是整个合约里最重要的活性保证。

### 三条贯穿全合约的规则

**1. 出款一律 pull，绝不 push。**
结算时只记账（`_prize[id][winner] += amount`），钱由各人自己来领。如果结算时批量
转账，只要有一个赢家是收款会 revert 的合约，所有人的钱都会卡住。
`test_rejectingReceiverDoesNotBlockOthers` 专门验证这一点。

**2. 组织者抽成上限写死在代码里**（`MAX_ORGANIZER_FEE_BPS = 1000`），不可配置、
不可治理。报名者事前可见。

**3. 任何状态都有出口。** 三种取消路径：

| 触发条件 | 谁能触发 |
|---------|---------|
| 报名截止前组织者主动取消 | 仅组织者 |
| 报名截止后人数不足 `minParticipants` | 任何人 |
| 超过 `resultDeadline` 仍未结算 | 任何人（活性逃生舱） |

注意组织者**不能**在报名截止后取消 —— 否则他可以看到形势不妙就掀桌。

### 状态机

```
          register / sponsor
                 ↓
Created ──→ [Open] ──settle──→ [Settled] ──claimPrize──→ 出款
                 │
                 └──cancel──→ [Cancelled] ──claimRefund──→ 退款
```

`Settled` 和 `Cancelled` 都是终态。

### 分账精度

整除会产生尘埃。做法是**把余数给冠军**，保证 `sum(_prize) == prizePool` 精确成立，
合约里不留残值。`testFuzz_settlementIsExact` 在任意报名费和抽成比例下断言这一点。

### 关键测试

| 测试 | 守什么 |
|------|--------|
| `invariant_solvent` | 合约余额恒等于"收进来减付出去"，12.8 万次随机调用 |
| `invariant_neverPaysOutMoreThanTakenIn` | 合约不会凭空造钱 |
| `test_organizerCannotTouchPrincipal` | 逐条探测提款后门，并验证零抽成时组织者一分领不到 |
| `test_cancel_escapeHatchWhenSubmitterVanishes` | 提交方失踪时资金能全额退回 |
| `test_rejectingReceiverDoesNotBlockOthers` | 一个坏收款人不拖垮所有人 |
| `test_settle_rejectsDuplicateWinner` | 同一人不能占两个名次多拿钱 |

## MatchAttestation —— 对局结果存证

### 它保证什么、不保证什么

**保证**：结果一旦公布就不能被悄悄修改。
**不保证**：结果一开始就是真的 —— 游戏服务器仍可在提交前造假。

这是**可验证性，不是可信性**。两者不能混为一谈，对外讲的时候也不能含糊。

### 核验流程

链上只花 1 个 slot，却覆盖完整结果：

1. 对局结束，游戏服务器把完整结果序列化成 blob：
   `{matchId, players[], scores[], placements[], endedAt, ...}`
2. `resultHash = keccak256(blob)`，调 `attest(matchId, resultHash)`
3. blob 本身通过普通 API 提供（`GET /v1/matches/{matchId}`）
4. 任何人拿到 blob 自己算哈希，与链上 `resultOf(matchId)` 比对

哈希覆盖了 blob 的每个字节 —— 改任何一个数字都对不上。

### 存储设计

只把 `resultHash` 写进 storage，时间戳和提交者放在**事件**里。事件比 storage 便宜
一个数量级，而核验本来就发生在链下，读事件完全够用。

唯一必须进 storage 的是 `resultHash` 本身，因为它承担一个只有链上才能给的保证：
**同一个 matchId 不能被二次存证**。没有这条，提交方就能事后为同一场比赛发布另一个
结果，存证也就失去意义了。连 admin 也不能覆盖，没有任何"修正"通道 ——
有的话就不叫存证了（`test_attest_adminCannotOverwriteEither`）。

### 实测成本

```
单场 attest        : 54,451 gas
批量 100 场总计     : 2,479,157 gas
批量摊到每场       : 24,791 gas
```

批量摊薄约 2.2 倍，每场基本就是一个 SSTORE 的成本。

### 为什么这个功能适合 Monad

**这是目前唯一能回答"为什么必须在 Monad 上做"的功能。**

皮肤 NFT 在任何 EVM 链上都能跑，没有 Monad 特异性。而"每局都写"在通用链上是要
精打细算的（要不要写？写多少？多久批一次？），在 Monad 上这个取舍基本消失。

诚实地说：这不是"独有能力"，而是**成本和确认速度让取舍这件事本身消掉了**。
`attestBatch` 进一步摊薄单场成本，让结算服务可以按批写入。

## 后续可考虑

按价值排序，都还没做：

| 功能 | 占哪条 | 备注 |
|------|--------|------|
| UGC 皮肤创作者分成 | ①③④ | 复用 `GameAssetRegistry` + EIP-2981，加 `creator` 字段。叙事上是最大的一跃 |
| 皮肤合成 / 升级 | ① | 烧两件低阶合一件高阶，用到现有 `burn`，`maxSupply` 天然限制高阶数量 |
| 皮肤租赁（ERC-4907） | ① | 几乎免费：`entitlement-check` 已存在，把 `ownerOf` 改成 `userOf` 即可 |
| 战队金库 | ② | 与赛事托管天然衔接 |
| 赛季排行榜 root 上链 | ③ | 一次 SSTORE |
